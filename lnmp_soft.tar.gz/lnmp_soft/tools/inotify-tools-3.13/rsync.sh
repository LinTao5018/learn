#!/bin/bash

from_dir="/usr/local/nginx/html/"
RYSBC_CMD="rsync -az --delete $from_dir root@201.1.2.200:/usr/local/nginx/html"

while inotifywait -rqq $from_dir
do
	$RYSBC_CMD
done &
